def calculate_discount(quantity, price, discount_rate):
    discount_amount = price * quantity * discount_rate
    discounted_price = (price * quantity) - discount_amount
    return discount_amount, discounted_price

# Example usage
quantity = 10
price = 15.0
discount_rate = 0.1

discount_amount, discounted_price = calculate_discount(quantity, price, discount_rate)
print(f"Quantity: {quantity}")
print(f"Price: ${price}")
print(f"Discount Amount: ${discount_amount}")
print(f"Discounted Price: ${discounted_price}")
