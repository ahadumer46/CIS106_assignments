# Global variables
total = 0
tax = 0

def calculate_total_and_tax(quantity, unit_price):
    global total, tax
    total = quantity * unit_price
    tax = total * 0.07
    return total, tax

# Example usage
quantity = 5
unit_price = 25.0

total, tax = calculate_total_and_tax(quantity, unit_price)
print(f"Total: ${total}")
print(f"Tax: ${tax}")
