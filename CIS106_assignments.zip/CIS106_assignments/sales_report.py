def calculate_commission(sales):
    if sales > 100000:
        commission = sales * 0.10
    else:
        commission = sales * 0.05
    next_year_target = sales * 0.05
    return commission, next_year_target

# Example usage
last_name = "Smith"
sales = 120000

commission, next_year_target = calculate_commission(sales)
print(f"Salesperson Last Name: {last_name}")
print(f"Commission: ${commission}")
print(f"Next Year's Target: ${next_year_target}")
