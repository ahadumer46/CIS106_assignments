def calculate_scores(exam_scores):
    total_points = sum(exam_scores)
    average_score = total_points / len(exam_scores)
    return total_points, average_score

# Example usage
last_name = "Doe"
exam_scores = [85, 92, 78]

total_points, average_score = calculate_scores(exam_scores)
print(f"Student Last Name: {last_name}")
print(f"Total Points: {total_points}")
print(f"Average Score: {average_score}")
