def calculate_bowling_scores(game_scores, handicap):
    average_score = sum(game_scores) / len(game_scores)
    average_with_handicap = average_score + handicap
    return average_score, average_with_handicap

# Example usage
last_name = "Johnson"
game_scores = [150, 180, 170]
handicap = 20

average_score, average_with_handicap = calculate_bowling_scores(game_scores, handicap)
print(f"Bowler Last Name: {last_name}")
print(f"Average Score: {average_score}")
print(f"Average Score with Handicap: {average_with_handicap}")
